document.getElementById("year").textContent = new Date().getFullYear();
// Before publishing, replace the placeholder WhatsApp number in index.html.
// Format: country code + number, digits only; India example: 919876543210.

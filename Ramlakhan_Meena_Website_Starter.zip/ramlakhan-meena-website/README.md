# Ramlakhan Meena — Personal Website

A mobile-friendly static personal website built with HTML, CSS and JavaScript.

## Files
- `index.html` — page content and SEO metadata
- `styles.css` — responsive premium dark theme
- `script.js` — current year helper
- `favicon.svg` — browser icon
- `robots.txt` and `sitemap.xml` — starter SEO files

## Before publishing
1. Open `index.html` and replace `91XXXXXXXXXX` with your WhatsApp number, including country code and digits only.
2. Replace `hello@example.com` with your email address.
3. Edit the About section to add your real bio, interests, work and social profile links.
4. Replace `https://example.com` in `robots.txt` and `sitemap.xml` after publishing.
5. Add a real profile photo if you want one; the current initials card is a designed placeholder.

## Free publishing option: GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a public repository named `yourusername.github.io`.
3. Upload all website files from this folder to the repository root.
4. In repository Settings → Pages, enable deployment from the main branch (root) if not already enabled.
5. Open `https://yourusername.github.io` after deployment finishes.

A free host may provide a free subdomain. A custom domain usually costs money.

## Google visibility
After the site is public:
1. Open Google Search Console and add the published site.
2. Verify ownership using the method offered by Search Console.
3. Submit `https://YOUR-PUBLISHED-DOMAIN/sitemap.xml`.
4. Use URL Inspection to request indexing.
Google decides if and when to index the site; this cannot be guaranteed.

## Admin panel and online payments
This starter project is a static public website. It does **not** include a secure admin panel, database, or live payment processing yet. Do not collect passwords or payment details with a plain HTML form. To add these properly, you need an authenticated backend and a payment provider account. Payment providers may charge transaction fees even if initial setup is free. Since this is a personal profile, add payments only if you have a real use case (such as donations or paid services).
